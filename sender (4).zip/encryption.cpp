#include "encryption.h"
void encrypt() {}