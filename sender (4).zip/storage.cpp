#include "storage.h"
void save_data() {}