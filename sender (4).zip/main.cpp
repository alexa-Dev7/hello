#include <iostream>
int main() { std::cout << "Chat server starting..."; return 0; }