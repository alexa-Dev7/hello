#ifndef WEBSOCKET_SERVER_H
#define WEBSOCKET_SERVER_H
void start_server();
#endif