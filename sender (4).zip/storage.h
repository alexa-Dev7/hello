#ifndef STORAGE_H
#define STORAGE_H
void save_data();
#endif