#ifndef ENCRYPTION_H
#define ENCRYPTION_H
void encrypt();
#endif